#include <stdio.h>
#include <stdlib.h>

typedef  struct
{ 
	char  *ch;
	int   len;
}HString;
