#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char* HuffmanCode;

typedef struct {
    unsigned int weight;
    unsigned int parent, LChild, RChild;
} HTNode, *HuffmanTree;

void select(HuffmanTree ht, int n, int *s1, int *s2) {
    int i;
    int min1 = 0, min2 = 0;
    
    for (i = 1; i <= n; i++) {
        if (ht[i].parent == 0) {
            if (min1 == 0 || ht[i].weight < ht[min1].weight) {
                min2 = min1;
                min1 = i;
            } else if (min2 == 0 || ht[i].weight < ht[min2].weight) {
                min2 = i;
            }
        }
    }

    *s1 = min1;
    *s2 = min2;
}

//6.20 ������������
void CrtHuffmanTree(HuffmanTree *ht, int *w, int n) {
    int m = 2 * n - 1;
    int i, s1, s2;

    *ht = (HuffmanTree)malloc((m + 1) * sizeof(HTNode));
    
    for (i = 1; i <= n; i++) {
        (*ht)[i].weight = w[i];
        (*ht)[i].parent = 0;
        (*ht)[i].LChild = 0;
        (*ht)[i].RChild = 0;
    }
    for (i = n + 1; i <= m; i++) {
        (*ht)[i].weight = 0;
        (*ht)[i].parent = 0;
        (*ht)[i].LChild = 0;
        (*ht)[i].RChild = 0;
    }

    for (i = n + 1; i <= m; i++) {
        select(*ht, i - 1, &s1, &s2);
        (*ht)[s1].parent = i;
        (*ht)[s2].parent = i;
        (*ht)[i].LChild = s1;
        (*ht)[i].RChild = s2;
        (*ht)[i].weight = (*ht)[s1].weight + (*ht)[s2].weight;
    }
}

void outputHuffman(HuffmanTree HT, int m) {
    if (m != 0) {
        printf("%d  ", HT[m].weight);
        outputHuffman(HT, HT[m].LChild);
        outputHuffman(HT, HT[m].RChild);
    }
}

//6.21 ����������
void CrtHuffmanCode(HuffmanTree *ht, HuffmanCode **hc, int n) {
    char *cd;
    int i, c, p;
    int start;

    *hc = (HuffmanCode *)malloc((n + 1) * sizeof(char *));
    cd = (char *)malloc(n * sizeof(char));
    cd[n - 1] = '\0';

    for (i = 1; i <= n; i++) {
        start = n - 1;
        for (c = i, p = (*ht)[i].parent; p != 0; c = p, p = (*ht)[p].parent) {
            if ((*ht)[p].LChild == c)
                cd[--start] = '0';
            else
                cd[--start] = '1';
        }
        (*hc)[i] = (char *)malloc((n - start) * sizeof(char));
        strcpy((*hc)[i], &cd[start]);
    }

    free(cd);

    for (i = 1; i <= n; i++)
        printf("ȨֵΪ %d �Ľڵ����Ϊ: %s\n", (*ht)[i].weight, (*hc)[i]);
}

int main() {
    HuffmanTree HT;
    HuffmanCode *HC;
    int *w;
    int i, n, wei;
    int m;

    printf("6.20 ���������������Ҷ�ӽ�����: ");
    scanf("%d", &n);

    w = (int *)malloc((n + 1) * sizeof(int));
    for (i = 1; i <= n; i++) {
        printf("������� %d ��Ԫ�ص�Ȩֵ: ", i);
        scanf("%d", &wei);
        w[i] = wei;
    }

    CrtHuffmanTree(&HT, w, n);
    m = 2 * n - 1;

    printf("\n���������������������Ȩֵ��ʾ��:\n");
    outputHuffman(HT, m);
    printf("\n\n 6.21 ��������������:\n");
    CrtHuffmanCode(&HT, &HC, n);

    // �ͷ���Դ
    for (i = 1; i <= n; i++)
        free(HC[i]);
    free(HC);
    free(HT);
    free(w);

    return 0;
}
