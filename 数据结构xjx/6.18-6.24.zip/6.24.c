#include <stdio.h>
#include <stdlib.h>

#define TRUE  1
#define FALSE 0
#define ERROR 0
#define OK    1
#define MAXSIZE 50

typedef char DataType;

typedef struct Node {
    DataType data;
    struct Node *LChild;
    struct Node *RChild;
} BiTNode, *BiTree;

// ��������������չ���������
void CreateBiTree(BiTree *bt) {
    char ch = getchar();
    if (ch == '.' || ch == '\n') {
        *bt = NULL;
    } else {
        *bt = (BiTree)malloc(sizeof(BiTNode));
        if (!*bt) {
            fprintf(stderr, "Memory allocation failed.\n");
            exit(EXIT_FAILURE);
        }
        (*bt)->data = ch;
        CreateBiTree(&((*bt)->LChild));
        CreateBiTree(&((*bt)->RChild));
    }
}

typedef BiTree QueueElementType;

typedef struct {
    QueueElementType element[MAXSIZE];
    int front;
    int rear;
} SeqQueue;

void InitQueue(SeqQueue *Q) {
    Q->front = Q->rear = 0;
}

int EnterQueue(SeqQueue *Q, QueueElementType x) {
    if ((Q->rear + 1) % MAXSIZE == Q->front)  // ����
        return FALSE;
    Q->element[Q->rear] = x;
    Q->rear = (Q->rear + 1) % MAXSIZE;
    return TRUE;
}

int DeleteQueue(SeqQueue *Q, QueueElementType *x) {
    if (Q->front == Q->rear)  // �ӿ�
        return FALSE;
    *x = Q->element[Q->front];
    Q->front = (Q->front + 1) % MAXSIZE;
    return TRUE;
}

int IsEmpty(SeqQueue *Q) {
    return Q->front == Q->rear;
}

//6.24 ��α���������
int LayerOrder(BiTree bt) {
    if (bt == NULL)
        return ERROR;

    SeqQueue Q;
    InitQueue(&Q);
    EnterQueue(&Q, bt);

    printf("��α���������Ϊ: ");
    while (!IsEmpty(&Q)) {
        BiTree p;
        DeleteQueue(&Q, &p);
        printf("%c  ", p->data);
        if (p->LChild)
            EnterQueue(&Q, p->LChild);
        if (p->RChild)
            EnterQueue(&Q, p->RChild);
    }
    printf("\n");
    return OK;
}

int main(void) {
    BiTree T;
    printf("����չ����������н���������������������:\n");
    CreateBiTree(&T);
    LayerOrder(T);
    return 0;
}
