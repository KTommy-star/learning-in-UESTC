#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTEX_NUM 20
#define Error -1
#define Ok 1

/* �ڽӱ��ṹ���� */
typedef struct ArcNode {
    int adjvex;                 // �ڽӵ��±�
    int weight;                // Ȩ�أ���ʡ�ԣ�
    struct ArcNode *nextarc;   // ��һ����
} ArcNode;

typedef struct VertexNode {
    char data;                // ������
    ArcNode *firstarc;        // ��һ����
} VertexNode;

typedef struct {
    VertexNode vertexes[MAX_VERTEX_NUM];
    int vexnum;   // ������
    int arcnum;   // ����
} Graph;

/* ջ�ṹ */
typedef struct {
    int data[MAX_VERTEX_NUM];
    int top;
} Stack;

void InitStack(Stack *S) {
    S->top = 0;
}

int Push(Stack *S, int x) {
    if (S->top >= MAX_VERTEX_NUM) return 0;
    S->data[S->top++] = x;
    return 1;
}

int Pop(Stack *S, int *x) {
    if (S->top <= 0) return 0;
    *x = S->data[--S->top];
    return 1;
}

int IsEmpty(Stack S) {
    return S.top == 0;
}

/* ��ÿ���������� */
void FindID(Graph G, int indegree[MAX_VERTEX_NUM]) {
    for (int i = 0; i < G.vexnum; i++)
        indegree[i] = 0;

    for (int i = 0; i < G.vexnum; i++) {
        ArcNode *p = G.vertexes[i].firstarc;
        while (p != NULL) {
            indegree[p->adjvex]++;
            p = p->nextarc;
        }
    }
}

//7.11 ��������
int TopoSort(Graph G) {
    Stack S;
    int indegree[MAX_VERTEX_NUM];
    int i, count, k;
    ArcNode *p;

    FindID(G, indegree);  // �������
    InitStack(&S);

    for (i = 0; i < G.vexnum; i++)
        if (indegree[i] == 0)
            Push(&S, i);  // �����Ϊ0�Ķ�����ջ

    count = 0;
    while (!IsEmpty(S)) {
        Pop(&S, &i);
        printf("%c ", G.vertexes[i].data);
        count++;  // �����ͳ��
        p = G.vertexes[i].firstarc;
        while (p != NULL) {
            k = p->adjvex;
            indegree[k]--;
            if (indegree[k] == 0)
                Push(&S, k);
            p = p->nextarc;
        }
    }

    if (count < G.vexnum)
        return Error;  // �л�
    else
        return Ok;
}

/* ��������ͼ A��B, A��C, B��D, C��D, D��E */
void CreateSampleGraph(Graph *G) {
    int i;
    G->vexnum = 5;
    G->arcnum = 5;

    for (i = 0; i < G->vexnum; i++) {
        G->vertexes[i].data = 'A' + i;
        G->vertexes[i].firstarc = NULL;
    }

    ArcNode *p;

    // A �� B
    p = (ArcNode *)malloc(sizeof(ArcNode));
    p->adjvex = 1;
    p->nextarc = G->vertexes[0].firstarc;
    G->vertexes[0].firstarc = p;

    // A �� C
    p = (ArcNode *)malloc(sizeof(ArcNode));
    p->adjvex = 2;
    p->nextarc = G->vertexes[0].firstarc;
    G->vertexes[0].firstarc = p;

    // B �� D
    p = (ArcNode *)malloc(sizeof(ArcNode));
    p->adjvex = 3;
    p->nextarc = G->vertexes[1].firstarc;
    G->vertexes[1].firstarc = p;

    // C �� D
    p = (ArcNode *)malloc(sizeof(ArcNode));
    p->adjvex = 3;
    p->nextarc = G->vertexes[2].firstarc;
    G->vertexes[2].firstarc = p;

    // D �� E
    p = (ArcNode *)malloc(sizeof(ArcNode));
    p->adjvex = 4;
    p->nextarc = G->vertexes[3].firstarc;
    G->vertexes[3].firstarc = p;
}

int main() {
    Graph G;
    CreateSampleGraph(&G);
    printf("����������:\n");
    if (TopoSort(G) == Error)
        printf("\n��ͼ�л����޷�������������\n");
    else
        printf("\n��������ɹ���\n");
    return 0;
}
