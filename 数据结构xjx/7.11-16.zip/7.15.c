#include <stdio.h>
#include <stdlib.h>

#define INFINITY 10000
#define VERTEX_NUM 7  // ������1-6��0��ʹ��
#define EDGE_NUM 9

int Graph[VERTEX_NUM][VERTEX_NUM] = {
// 0     1     2     3     4     5     6
{INFINITY, INFINITY, INFINITY, INFINITY, INFINITY, INFINITY, INFINITY},  // 0
{INFINITY, INFINITY, 6, 3, INFINITY, INFINITY, INFINITY},  // 1
{INFINITY, INFINITY, INFINITY, INFINITY, 5, INFINITY, INFINITY},  // 2
{INFINITY, INFINITY, 2, INFINITY, 3, 4, INFINITY},  // 3
{INFINITY, INFINITY, INFINITY, INFINITY, INFINITY, INFINITY, 3},  // 4
{INFINITY, INFINITY, INFINITY, INFINITY, 2, INFINITY, 5},  // 5
{INFINITY, INFINITY, INFINITY, INFINITY, INFINITY, INFINITY, INFINITY}   // 6
};

int Visited[VERTEX_NUM];
int Path[VERTEX_NUM];
int Distance[VERTEX_NUM];

//7.15 ͼ�����·���㷨
void Dijkstra(int Start) {
    int MinEdge, CurrentVertex, i, j, Step;
    Step = 1;
    Visited[Start] = 1;

    // ��ʼ����������
    for (i = 1; i < VERTEX_NUM; i++) {
        Distance[i] = Graph[Start][i];
    }
    Distance[Start] = 0;

    // ��ӡ��ͷ
    printf("Step  ");
    for (i = 1; i < VERTEX_NUM; i++) {
        printf("%3d ", i);
    }
    printf("\n--------------------------------\n");

    // ��ʼ״̬���
    printf("%2d: ", Step);
    for (i = 1; i < VERTEX_NUM; i++) {
        if (Distance[i] == INFINITY) printf("  * ");
        else printf("%3d ", Distance[i]);
    }
    printf("\n");

    // ��ѭ��
    while (Step < VERTEX_NUM - 1) {
        Step++;
        MinEdge = INFINITY;

        // �ҵ���ǰ��С����Ķ���
        for (j = 1; j < VERTEX_NUM; j++) {
            if (Visited[j] == 0 && MinEdge > Distance[j]) {
                CurrentVertex = j;
                MinEdge = Distance[j];
            }
        }

        Visited[CurrentVertex] = 1;
        printf("%2d: ", Step);

        // �����ڽӶ������
        for (j = 1; j < VERTEX_NUM; j++) {
            if (Visited[j] == 0 && Distance[CurrentVertex] + Graph[CurrentVertex][j] < Distance[j]) {
                Distance[j] = Distance[CurrentVertex] + Graph[CurrentVertex][j];
                Path[j] = CurrentVertex;
            }

            // ��ӡ��ǰ����
            if (Distance[j] == INFINITY) printf("  * ");
            else printf("%3d ", Distance[j]);
        }
        printf("\n");
    }
}

int main() {
    int i, k;

    // ��ʼ��
    for (i = 0; i < VERTEX_NUM; i++) {
        Visited[i] = 0;
        Path[i] = 1;  // Ĭ��ǰ���������1
    }

    printf("Dijkstra Algorithm Steps:\n");
    Dijkstra(1);

    // ����������·��
    printf("\nAll Shortest Paths from Vertex 1:\n");
    printf("------------------------------\n");
    for (i = 2; i < VERTEX_NUM; i++) {
        printf("To %d (Distance: %2d): ", i, Distance[i]);
        k = i;

        // ����׷��·��
        do {
            printf("%d", k);
            if (Path[k] != 1) printf(" <- ");
            k = Path[k];
        } while (k != 1);

        printf(" <- 1\n");
    }

    return 0;
}