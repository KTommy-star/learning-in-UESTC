#include <stdio.h>
#include <malloc.h>

#define MAXSIZE 1000
#define ElementType int
#define m1 3
#define n1 4

/*稀疏矩阵三元组表的类型定义*/
typedef struct
{
    int row,col;  /*该非零元素的行下标和列下标*/
    ElementType e; /*该非零元素的值*/
}Triple;
typedef struct
{
    Triple data[MAXSIZE+1];   /* 非零元素的三元组表。data[0]未用*/
    int m,n,len;          /*矩阵的行数、列数和非零元素的个数*/
}TSMatrix;

/*5.1 采用矩阵的正常存储方式（二维数组）实现矩阵转置*/
void TransMatrix(ElementType source[m1][n1],ElementType dest[n1][m1])
{
    /*Source和dest分别为被转置的矩阵和转置以后的矩阵（用二维数组表示）*/
    int i,j;
    for(i=0;i<m1;i++)
        for (j=0;j<n1;j++)
            dest[j][i]=source[i][j];
}

/*5.2 "列序"递增转置法*/
void TransposeTSMatrix(TSMatrix A,TSMatrix *B)
{ /*把矩阵A转置到B所指向的矩阵中去。矩阵用三元组表表示*/
    int i,j,k;
    B->m=A.n;
    B->n=A.m;
    B->len=A.len;
    if(B->len>0)
    {
        j=1;				/*j为辅助计数器，记录转置后的三元组在三元组表B中的下标值ֵ*/
        for(k=1; k<=A.n; k++) /*扫描三元组表A 共k次，每次寻找列值为k的三元组进行转置*/
            for(i=1; i<=A.len; i++)
                if(A.data[i].col==k)
                {
                    B->data[j].row=A.data[i].col;/*从头至尾扫描三元组表A,寻找col值为k的三元组进行转置*/
                    B->data[j].col=A.data[i].row;
                    B->data[j].e=A.data[i].e;
                    j++;		/*计数器j自加，指向下一个存放转置后三元组的下标*/
                }/*内循环中if的结束*/
    }/* if(B->len>0)的结束*/
}/* end of TransposeTSMatrix */

/*5.3 "按位快速转置"法*/
void FastTransposeTSMatrix(TSMatrix A,TSMatrix *B)
{
    /*基于矩阵的三元组表示，采用"按位快速转置"法，将矩阵A转置为矩阵B*/
    int col,t,p,q;
    int num[MAXSIZE], position[MAXSIZE];
    B->len=A.len;
    B->n=A.m;
    B->m=A.n;
    if(B->len)
    {
        for(col=1;col<=A.n;col++)
            num[col]=0;
        for(t=1;t<=A.len;t++)
            num[A.data[t].col]++; /*计算每一列的非零元素的个数*/
        position[1]=1;
        for(col=2;col<=A.n;col++)  /*求col列中第一个非零元素在B.data[ ]中的正确位置*/
            position[col]=position[col-1]+num[col-1];
        for(p=1;p<=A.len;p++)/*将被转置矩阵的三元组表A从头至尾扫描一次，实现矩阵转置*/
        {
            col=A.data[p].col;
            q=position[col];
            B->data[q].row=A.data[p].col;
            B->data[q].col=A.data[p].row;
            B->data[q].e=A.data[p].e;
            position[col]++;/* position[col]加1，指向下一个列号为col的非零元素在三元组表B中的下标值*/
        }/*end of for*/
    }
}


int main()
{
    //5.1 采用矩阵的正常存储方式（二维数组）实现矩阵转置
    ElementType source[m1][n1] = { // 直接初始化矩阵
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9, 10, 11, 12}
    };
    ElementType dest[n1][m1]; // 目标矩阵
    TransMatrix(source, dest); // 调用转置函数
    // 输出转置后的矩阵
    printf("转置后的矩阵：\n");
    for (int i = 0; i < n1; i++) {
        for (int j = 0; j < m1; j++) {
            printf("%d ", dest[i][j]);
        }
        printf("\n");
    }

    //5.2 "列序"递增转置法
    int i;
    int a[8]={1,1,3,3,4,5,6,6};
    int b[8]={2,3,1,6,3,2,1,4};
    int c[8]={12,9,-3,14,24,18,15,-7};
    TSMatrix A;
    TSMatrix *B;
    A.n=8;
    A.m=1;
    A.len=8;
    B=(TSMatrix *)malloc(sizeof(TSMatrix));
    for(i=0;i<8;i++)
    {
        A.data[i+1].row=a[i];
        A.data[i+1].col=b[i];
        A.data[i+1].e=c[i];
    }
    TransposeTSMatrix(A,B); //此处可以更改5.2与5.3两个算法
    for(i=1;i<=8;i++)
    {
        printf("%3d",B->data[i].row);
    }
    printf("\n");
    for(i=1;i<=8;i++)
    {
        printf("%3d",B->data[i].col);
    }
    printf("\n");
    for(i=1;i<=8;i++)
    {
        printf("%3d",B->data[i].e);
    }
    printf("\n");
    getchar();

    return 0;
}

