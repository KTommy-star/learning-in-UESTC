﻿#include <stdio.h>
#include <stdlib.h>

#define OK 1
#define ERROR 0

typedef char AtomType; // 假设原子类型是char

typedef enum {ATOM, LIST} ElemTag;

typedef struct GLNode {
    ElemTag tag;
    union {
        AtomType atom;
        struct {
            struct GLNode *hp, *tp;
        } htp;
    } atom_htp;
} GLNode, *GList;

// 5.5 求广义表的表头
GList Head(GList L) {
    if (L == NULL) return NULL;
    if (L->tag == ATOM) {
        printf("Error: Atom does not have a head\n");
        exit(EXIT_FAILURE);
    }
    return L->atom_htp.htp.hp;
}

// 5.6 求广义表的表尾
GList Tail(GList L) {
    if (L == NULL) return NULL;
    if (L->tag == ATOM) {
        printf("Error: Atom does not have a tail\n");
        exit(EXIT_FAILURE);
    }
    return L->atom_htp.htp.tp;
}

// 5.7 计算广义表的长度
int Length(GList L) {
    int n = 0;
    GList s = L;
    while (s != NULL) {
        n++;
        s = s->atom_htp.htp.tp;
    }
    return n;
}

// 5.8 计算广义表的深度
int Depth(GList L) {
    if (L == NULL) return 1;  // 空表深度为 1
    if (L->tag == ATOM) return 1;  // 原子自身深度应该是 1

    int max = 0;  // 初始化 max，防止随机值影响结果
    int d;
    GList s = L;
    while (s != NULL) {
        d = Depth(s->atom_htp.htp.hp);
        if (d > max) max = d;
        s = s->atom_htp.htp.tp;
    }
    return max + 1;  // 广义表深度 = 最深子表深度 + 1
}


// 5.9 计算原子数量
int CountAtom(GList L) {
    if (L == NULL) return 0;
    if (L->tag == ATOM) return 1;
    return CountAtom(L->atom_htp.htp.hp) + CountAtom(L->atom_htp.htp.tp);
}
//下面是另一种计算原子数量方法
//int CountAtom(GList L)
//{
//    int n1, n2;
//    if(L==NULL)
//        return(0);    /* 空表中没有原子 */
//    if(L->tag==ATOM)
//        return(1);    /* L指向单个原子 */
//    n1=CountAtom(L->atom_htp.htp.hp);    /* 求表头中的原子数目 */
//    n2=CountAtom(L->atom_htp.htp.tp);    /* 求表尾中的原子数目 */
//    return(n1+n2);
//}


// 5.10 复制广义表
int CopyGList(GList S, GList *T) {
    if (S == NULL) {
        *T = NULL;
        return OK;
    }

    *T = (GLNode *)malloc(sizeof(GLNode));
    if (*T == NULL) return ERROR;

    (*T)->tag = S->tag;
    if (S->tag == ATOM)
        (*T)->atom_htp.atom = S->atom_htp.atom;
    else {
        CopyGList(S->atom_htp.htp.hp, &((*T)->atom_htp.htp.hp));
        CopyGList(S->atom_htp.htp.tp, &((*T)->atom_htp.htp.tp));
    }
    return OK;
}

// 创建一个原子节点
GList CreateAtomNode(AtomType atom) {
    GList node = (GList)malloc(sizeof(GLNode));
    node->tag = ATOM;
    node->atom_htp.atom = atom;
    return node;
}

// 创建一个表节点
GList CreateListNode(GList hp, GList tp) {
    GList node = (GList)malloc(sizeof(GLNode));
    node->tag = LIST;
    node->atom_htp.htp.hp = hp;
    node->atom_htp.htp.tp = tp;
    return node;
}

// 测试函数
void Test() {
    GList a = CreateAtomNode('A');
    GList b = CreateAtomNode('B');
    GList c = CreateAtomNode('C');

    // 创建一个子表 (A, B)
    GList sublist = CreateListNode(a, CreateListNode(b, NULL));

    // 创建一个广义表 ((A, B), C)
    GList list = CreateListNode(sublist, CreateListNode(c, NULL));

    // 长度
    printf("Length: %d\n", Length(list));
    // 深度
    printf("Depth: %d\n", Depth(list));
    // 数量
    printf("Atom count: %d\n", CountAtom(list));

    // 复制广义表
    GList copy;
    CopyGList(list, &copy);
    printf("Copy successful, Length of copy: %d\n", Length(copy));

    // 测试 Head 和 Tail
    GList head = Head(list);
    GList tail = Tail(list);

    if (head && head->tag == LIST) {
        printf("Head is a LIST, first element is: %c\n", head->atom_htp.htp.hp->atom_htp.atom); // 'A'
    } else if (head && head->tag == ATOM) {
        printf("Head is an ATOM: %c\n", head->atom_htp.atom);
    } else {
        printf("Head is NULL\n");
    }

    if (tail && tail->tag == LIST) {
        printf("Tail is a LIST, first element is: %c\n", tail->atom_htp.htp.hp->atom_htp.atom); // 'C'
    } else if (tail && tail->tag == ATOM) {
        printf("Tail is an ATOM: %c\n", tail->atom_htp.atom);
    } else {
        printf("Tail is NULL\n");
    }
}

// 主函数
int main() {
    Test();
    return 0;
}
